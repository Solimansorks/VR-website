import { Button } from "@/components/ui/button";
import { Play, ArrowRight, Globe, Users, Camera } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Gradient Background */}
      <div className="absolute inset-0 hero-gradient"></div>
      
      {/* Decorative shapes */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-orange-400/10 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 left-1/2 w-48 h-48 bg-blue-400/10 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 text-center text-white">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Badge */}
          <div className="inline-flex items-center px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-sm font-medium">
            <Globe className="w-4 h-4 mr-2" />
            الأداة رقم 1 للجولات الافتراضية في العالم
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold font-poppins leading-tight">
            <span className="block">جولات افتراضية</span>
            <span className="block text-transparent bg-gradient-to-r from-white to-orange-200 bg-clip-text">
              مذهلة
            </span>
          </h1>

          {/* Subheading */}
          <p className="text-xl md:text-2xl text-white/90 max-w-2xl mx-auto leading-relaxed">
            أنشئ وشارك واكتشف الجولات الافتراضية بسهولة. منصة احترافية لجولات 360 درجة تفاعلية
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              className="bg-white text-primary hover:bg-white/90 font-semibold px-8 py-6 text-lg h-auto"
            >
              ابدأ مجاناً - إنه مجاني!
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="border-white/30 text-white hover:bg-white/10 font-semibold px-8 py-6 text-lg h-auto backdrop-blur-sm"
            >
              <Play className="mr-2 h-5 w-5" />
              شاهد العرض التوضيحي
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-12">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Users className="w-6 h-6 mr-2" />
                <span className="text-3xl font-bold">50,000+</span>
              </div>
              <p className="text-white/80">مستخدم حول العالم</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Camera className="w-6 h-6 mr-2" />
                <span className="text-3xl font-bold">100,000+</span>
              </div>
              <p className="text-white/80">جولة افتراضية تم إنشاؤها</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Globe className="w-6 h-6 mr-2" />
                <span className="text-3xl font-bold">150+</span>
              </div>
              <p className="text-white/80">دولة حول العالم</p>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/60 rounded-full mt-2"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;