import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Globe, Camera, Users, Zap, Shield, Heart, Play } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HeroSection from "@/components/HeroSection";
import TourCard from "@/components/TourCard";
import panoramaHotel from "@/assets/panorama-hotel-lobby.jpg";
import panoramaApartment from "@/assets/panorama-apartment.jpg";
import panoramaGallery from "@/assets/panorama-gallery.jpg";

const Index = () => {
  const featuredTours = [
    {
      title: "فندق ريتز كارلتون الرياض",
      titleEn: "Ritz Carlton Riyadh Hotel",
      description: "جولة افتراضية فاخرة في أحد أفخم فنادق الرياض مع أجنحة مذهلة ومرافق عالمية المستوى",
      image: panoramaHotel,
      category: "فنادق",
      categoryEn: "Hotels",
      views: 15420,
      duration: "8 دقائق",
      location: "الرياض، السعودية",
      isPremium: true,
    },
    {
      title: "شقة سكنية فاخرة في دبي",
      titleEn: "Luxury Apartment in Dubai",
      description: "شقة عصرية بإطلالة رائعة على برج خليفة مع تصميم داخلي أنيق وأثاث فاخر",
      image: panoramaApartment,
      category: "عقارات",
      categoryEn: "Real Estate", 
      views: 8930,
      duration: "6 دقائق",
      location: "دبي، الإمارات",
      isPremium: false,
    },
    {
      title: "معرض الفن المعاصر",
      titleEn: "Contemporary Art Gallery",
      description: "جولة ثقافية في معرض فني يضم أعمال فنية معاصرة من فنانين عالميين ومحليين",
      image: panoramaGallery,
      category: "متاحف",
      categoryEn: "Museums",
      views: 5670,
      duration: "12 دقيقة",
      location: "جدة، السعودية",
      isPremium: false,
    },
  ];

  const features = [
    {
      icon: Camera,
      title: "إنشاء سهل",
      description: "أنشئ جولات افتراضية مذهلة بنقرات قليلة بدون خبرة تقنية"
    },
    {
      icon: Globe,
      title: "مشاركة واسعة",
      description: "شارك جولاتك على جميع المنصات ووسائل التواصل الاجتماعي"
    },
    {
      icon: Zap,
      title: "أداء عالي",
      description: "تحميل سريع وأداء ممتاز على جميع الأجهزة والمتصفحات"
    },
    {
      icon: Shield,
      title: "أمان عالي",
      description: "حماية متقدمة لبياناتك وجولاتك مع خصوصية كاملة"
    },
    {
      icon: Users,
      title: "إدارة الفرق",
      description: "تعاون مع فريقك وإدارة المشاريع بسهولة وفعالية"
    },
    {
      icon: Heart,
      title: "سهولة الاستخدام",
      description: "واجهة بديهية وسهلة الاستخدام للمبتدئين والمحترفين"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <HeroSection />

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">لماذا نحن الأفضل</Badge>
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-4">
              الأداة رقم 1 للجولات الافتراضية
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              <span className="font-semibold text-primary">أنشئ</span> و
              <span className="font-semibold text-accent">حرر</span> و
              <span className="font-semibold text-primary">شارك</span> جولاتك الافتراضية
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                  <CardContent className="p-8 text-center">
                    <div className="mx-auto mb-6 p-4 bg-primary/10 rounded-full w-fit">
                      <IconComponent className="w-8 h-8 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Tours */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">استكشف الجولات</Badge>
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-4">
              اكتشف الجولات المميزة
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              استكشف العالم من خلال جولات افتراضية مذهلة بتقنية 360 درجة
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredTours.map((tour, index) => (
              <TourCard key={index} {...tour} />
            ))}
          </div>

          <div className="text-center mt-12">
            <Button variant="outline" size="lg">
              عرض جميع الجولات
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">كيف يعمل</Badge>
            <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-4">
              بسيط وسهل في 3 خطوات
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              أنشئ جولتك الافتراضية الأولى في دقائق معدودة
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="mx-auto mb-6 p-6 bg-gradient-to-r from-primary to-accent rounded-full w-20 h-20 flex items-center justify-center">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">ارفع صورك</h3>
              <p className="text-muted-foreground">
                ارفع صورك البانورامية 360 درجة أو استخدم صور عادية
              </p>
            </div>
            
            <div className="text-center">
              <div className="mx-auto mb-6 p-6 bg-gradient-to-r from-accent to-orange-500 rounded-full w-20 h-20 flex items-center justify-center">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">أضف التفاعل</h3>
              <p className="text-muted-foreground">
                أضف نقاط التفاعل والانتقال والمعلومات بسهولة
              </p>
            </div>
            
            <div className="text-center">
              <div className="mx-auto mb-6 p-6 bg-gradient-to-r from-orange-500 to-red-500 rounded-full w-20 h-20 flex items-center justify-center">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">شارك واستمتع</h3>
              <p className="text-muted-foreground">
                شارك جولتك مع العالم واحصل على إحصائيات مفصلة
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center bg-gradient-to-r from-primary to-accent rounded-2xl p-12 text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              جاهز لإنشاء جولتك الأولى؟
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              انضم إلى أكثر من 50,000 مستخدم حول العالم واستكشف عالم الجولات الافتراضية
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold px-8">
                ابدأ مجاناً - إنه مجاني!
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" className="border-white/30 text-white hover:bg-white/10 font-semibold px-8 backdrop-blur-sm">
                <Play className="mr-2 h-5 w-5" />
                شاهد العرض التوضيحي
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
