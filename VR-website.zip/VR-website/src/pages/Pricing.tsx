import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Zap, Crown } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Pricing = () => {
  const plans = [
    {
      name: "مجاني",
      nameEn: "Free",
      price: 0,
      currency: "جنيه",
      period: "شهرياً",
      description: "مثالي للمبتدئين والاستخدام الشخصي",
      icon: Star,
      popular: false,
      features: [
        "3 جولات افتراضية شهرياً",
        "جودة عادية (HD)",
        "5 نقاط تفاعل لكل جولة",
        "مشاركة أساسية",
        "استضافة مجانية",
        "دعم عبر البريد الإلكتروني",
        "علامة مائية على الجولات",
      ],
      limitations: [
        "عدد محدود من الجولات",
        "ميزات أساسية فقط",
      ]
    },
    {
      name: "احترافي",
      nameEn: "Professional", 
      price: 299,
      currency: "حنيه",
      period: "شهرياً",
      description: "للمصورين المحترفين ووكلاء العقارات",
      icon: Zap,
      popular: true,
      features: [
        "جولات غير محدودة",
        "جودة عالية (4K)",
        "نقاط تفاعل غير محدودة",
        "إحصائيات مفصلة",
        "إزالة العلامة المائية",
        "دعم فني أولوية",
        "تخصيص العلامة التجارية",
        "تكامل مع مواقع التواصل",
        "خرائط تفاعلية",
      ],
      limitations: []
    },
    {
      name: "مؤسسي",
      nameEn: "Enterprise",
      price: 999,
      currency: "جنيه", 
      period: "شهرياً",
      description: "للشركات الكبرى والمؤسسات",
      icon: Crown,
      popular: false,
      features: [
        "كل ميزات الخطة الاحترافية",
        "فرق متعددة وإدارة المستخدمين",
        "API مخصص للتطوير",
        "استضافة مخصصة",
        "دعم فني 24/7",
        "تدريب مخصص",
        "تكامل مع الأنظمة الحالية",
        "تقارير مفصلة",
        "أمان مؤسسي",
        "نطاق فرعي مخصص",
      ],
      limitations: []
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Page Header */}
      <section className="bg-gradient-to-r from-primary to-accent text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold font-poppins mb-4">
            خطط الأسعار
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            اختر الخطة المناسبة لك وابدأ في إنشاء جولات افتراضية مذهلة
          </p>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan, index) => {
              const IconComponent = plan.icon;
              return (
                <Card 
                  key={index} 
                  className={`relative overflow-hidden transition-all duration-300 hover:scale-105 ${
                    plan.popular 
                      ? 'border-primary shadow-2xl ring-2 ring-primary/20' 
                      : 'hover:shadow-xl'
                  }`}
                >
                  {plan.popular && (
                    <Badge className="absolute top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-primary to-accent">
                      الأكثر شعبية
                    </Badge>
                  )}
                  
                  <CardHeader className={`text-center pb-8 ${plan.popular ? 'pt-12' : 'pt-8'}`}>
                    <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit">
                      <IconComponent className="w-8 h-8 text-primary" />
                    </div>
                    <h3 className="text-2xl font-bold font-poppins">{plan.name}</h3>
                    <p className="text-muted-foreground">{plan.description}</p>
                    <div className="mt-4">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      <span className="text-muted-foreground text-lg mr-2">{plan.currency}</span>
                      <span className="text-muted-foreground">/ {plan.period}</span>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <ul className="space-y-3">
                      {plan.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start">
                          <Check className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  
                  <CardFooter className="pt-6">
                    <Button 
                      className={`w-full ${
                        plan.popular 
                          ? 'button-gradient' 
                          : plan.name === 'مجاني' 
                            ? 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                            : ''
                      }`}
                      size="lg"
                    >
                      {plan.name === 'مجاني' ? 'ابدأ مجاناً' : 'اختر هذه الخطة'}
                    </Button>
                  </CardFooter>
                </Card>
              );
            })}
          </div>

          {/* FAQ Section */}
          <div className="mt-20 max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">الأسئلة الشائعة</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-2">هل يمكنني تغيير الخطة لاحقاً؟</h3>
                  <p className="text-muted-foreground text-sm">نعم، يمكنك الترقية أو الخفض من خطتك في أي وقت من لوحة التحكم.</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">هل توجد رسوم إضافية؟</h3>
                  <p className="text-muted-foreground text-sm">لا توجد رسوم خفية. السعر المعروض يشمل جميع الميزات المذكورة.</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">ما هي طرق الدفع المتاحة؟</h3>
                  <p className="text-muted-foreground text-sm">نقبل جميع البطاقات الائتمانية الرئيسية والتحويل البنكي.</p>
                </div>
              </div>
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-2">هل يمكنني إلغاء اشتراكي؟</h3>
                  <p className="text-muted-foreground text-sm">نعم، يمكنك إلغاء اشتراكك في أي وقت بدون رسوم إضافية.</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">هل توجد فترة تجريبية؟</h3>
                  <p className="text-muted-foreground text-sm">نعم، جميع الخطط المدفوعة تتضمن فترة تجريبية مجانية لمدة 14 يوم.</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">كيف يعمل الدعم الفني؟</h3>
                  <p className="text-muted-foreground text-sm">نوفر دعم فني عبر البريد الإلكتروني والدردشة المباشرة حسب خطتك.</p>
                </div>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-20 text-center bg-gradient-to-r from-primary to-accent rounded-2xl p-12 text-white">
            <h2 className="text-3xl font-bold mb-4">جاهز للبدء؟</h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              انضم إلى أكثر من 50,000 مستخدم حول العالم واستكشف عالم الجولات الافتراضية
            </p>
            <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold px-8">
              ابدأ تجربتك المجانية الآن
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Pricing;