import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Eye, Heart, Share2, Clock, MapPin } from "lucide-react";

interface TourCardProps {
  title: string;
  titleEn: string;
  description: string;
  image: string;
  category: string;
  categoryEn: string;
  views: number;
  duration: string;
  location: string;
  isPremium?: boolean;
}

const TourCard = ({ 
  title, 
  titleEn, 
  description, 
  image, 
  category, 
  categoryEn, 
  views, 
  duration, 
  location, 
  isPremium = false 
}: TourCardProps) => {
  return (
    <Card className="group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-[1.02]">
      <div className="relative overflow-hidden">
        <img 
          src={image} 
          alt={title}
          className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
        
        {/* Category Badge */}
        <Badge 
          variant="secondary" 
          className="absolute top-3 left-3 bg-white/90 text-primary backdrop-blur-sm"
        >
          {category}
        </Badge>
        
        {/* Premium Badge */}
        {isPremium && (
          <Badge 
            className="absolute top-3 right-3 bg-gradient-to-r from-orange-500 to-red-500 text-white"
          >
            مميز
          </Badge>
        )}
        
        {/* Stats overlay */}
        <div className="absolute bottom-3 left-3 flex items-center space-x-2 text-white text-sm">
          <div className="flex items-center space-x-1">
            <Eye className="w-4 h-4" />
            <span>{views.toLocaleString()}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>{duration}</span>
          </div>
        </div>
      </div>
      
      <CardContent className="p-6">
        <div className="space-y-3">
          <div className="flex items-start justify-between">
            <h3 className="font-semibold text-lg leading-tight group-hover:text-primary transition-colors">
              {title}
            </h3>
            <div className="flex items-center space-x-1 ml-2">
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <Heart className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <Share2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          <p className="text-muted-foreground text-sm line-clamp-2">
            {description}
          </p>
          
          <div className="flex items-center text-muted-foreground text-sm">
            <MapPin className="w-4 h-4 mr-1" />
            {location}
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="p-6 pt-0">
        <Button className="w-full button-gradient">
          استكشف الجولة
        </Button>
      </CardFooter>
    </Card>
  );
};

export default TourCard;