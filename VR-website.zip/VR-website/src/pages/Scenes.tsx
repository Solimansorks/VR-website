import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Play, Download, Edit, Share2, MoreVertical, Eye, MessageCircle } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import panoramaHotel from "@/assets/panorama-hotel-lobby.jpg";
import panoramaApartment from "@/assets/panorama-apartment.jpg";
import panoramaGallery from "@/assets/panorama-gallery.jpg";

const Scenes = () => {
  const [selectedScene, setSelectedScene] = useState<number | null>(null);

  const scenes = [
    {
      title: "مدخل الفندق الرئيسي",
      titleEn: "Main Hotel Entrance",
      description: "مشهد بانورامي لمدخل الفندق مع الإضاءة الفاخرة والديكورات الذهبية",
      image: panoramaHotel,
      hotspots: [
        { x: 30, y: 40, title: "البهو الرئيسي", type: "navigation" },
        { x: 70, y: 30, title: "مكتب الاستقبال", type: "info" },
        { x: 50, y: 60, title: "منطقة الجلوس", type: "navigation" }
      ],
      stats: { views: 1250, interactions: 89 }
    },
    {
      title: "غرفة المعيشة الفاخرة",
      titleEn: "Luxury Living Room",
      description: "مساحة معيشة عصرية بإطلالة ساحرة على المدينة",
      image: panoramaApartment,
      hotspots: [
        { x: 25, y: 50, title: "الشرفة", type: "navigation" },
        { x: 60, y: 35, title: "المطبخ", type: "navigation" },
        { x: 80, y: 45, title: "غرفة النوم", type: "navigation" },
        { x: 45, y: 70, title: "معلومات الأثاث", type: "info" }
      ],
      stats: { views: 856, interactions: 67 }
    },
    {
      title: "قاعة المعرض الفني",
      titleEn: "Art Gallery Hall",
      description: "قاعة عرض الأعمال الفنية المعاصرة مع إضاءة احترافية",
      image: panoramaGallery,
      hotspots: [
        { x: 20, y: 40, title: "اللوحة الرئيسية", type: "info" },
        { x: 50, y: 30, title: "القاعة التالية", type: "navigation" },
        { x: 75, y: 50, title: "منطقة الاستراحة", type: "navigation" },
        { x: 40, y: 60, title: "معلومات الفنان", type: "info" }
      ],
      stats: { views: 634, interactions: 45 }
    }
  ];

  const HotspotIcon = ({ type }: { type: string }) => {
    switch (type) {
      case "navigation":
        return <div className="w-6 h-6 bg-blue-500 rounded-full border-2 border-white shadow-lg animate-pulse"></div>;
      case "info":
        return <div className="w-6 h-6 bg-orange-500 rounded-full border-2 border-white shadow-lg flex items-center justify-center">
          <MessageCircle className="w-3 h-3 text-white" />
        </div>;
      default:
        return <div className="w-6 h-6 bg-green-500 rounded-full border-2 border-white shadow-lg"></div>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Page Header */}
      <section className="bg-gradient-to-r from-primary to-accent text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold font-poppins mb-4">
            المشاهد التفاعلية
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            استكشف المشاهد البانورامية مع النقاط التفاعلية والانتقال السلس
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Scene Viewer */}
            <div className="lg:col-span-2">
              <Card className="overflow-hidden">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold">
                        {selectedScene !== null ? scenes[selectedScene].title : scenes[0].title}
                      </h2>
                      <p className="text-muted-foreground">
                        {selectedScene !== null ? scenes[selectedScene].description : scenes[0].description}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4 mr-2" />
                        تحميل
                      </Button>
                      <Button variant="outline" size="sm">
                        <Share2 className="w-4 h-4 mr-2" />
                        مشاركة
                      </Button>
                      <Button variant="outline" size="sm">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="p-0">
                  <div className="relative">
                    <img 
                      src={selectedScene !== null ? scenes[selectedScene].image : scenes[0].image}
                      alt="Scene"
                      className="w-full h-96 object-cover"
                    />
                    
                    {/* Hotspots */}
                    {(selectedScene !== null ? scenes[selectedScene].hotspots : scenes[0].hotspots).map((hotspot, index) => (
                      <div
                        key={index}
                        className="absolute cursor-pointer group"
                        style={{ left: `${hotspot.x}%`, top: `${hotspot.y}%` }}
                      >
                        <HotspotIcon type={hotspot.type} />
                        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-1 bg-black/80 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                          {hotspot.title}
                        </div>
                      </div>
                    ))}
                    
                    {/* Play Button */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Button size="lg" className="button-gradient rounded-full w-16 h-16">
                        <Play className="w-8 h-8" />
                      </Button>
                    </div>
                    
                    {/* Stats Overlay */}
                    <div className="absolute bottom-4 left-4 flex items-center space-x-4 text-white text-sm">
                      <div className="flex items-center space-x-1 bg-black/50 px-2 py-1 rounded">
                        <Eye className="w-4 h-4" />
                        <span>{(selectedScene !== null ? scenes[selectedScene].stats.views : scenes[0].stats.views).toLocaleString()}</span>
                      </div>
                      <div className="flex items-center space-x-1 bg-black/50 px-2 py-1 rounded">
                        <MessageCircle className="w-4 h-4" />
                        <span>{selectedScene !== null ? scenes[selectedScene].stats.interactions : scenes[0].stats.interactions}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
                
                <CardFooter className="flex justify-between items-center">
                  <div className="flex space-x-2">
                    <Badge variant="secondary">360° View</Badge>
                    <Badge variant="outline">HD Quality</Badge>
                    <Badge variant="outline">Interactive</Badge>
                  </div>
                  <Button className="button-gradient">
                    <Edit className="w-4 h-4 mr-2" />
                    تحرير المشهد
                  </Button>
                </CardFooter>
              </Card>
              
              {/* Scene Controls */}
              <Card className="mt-6">
                <CardHeader>
                  <h3 className="text-lg font-semibold">أدوات التحكم</h3>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Button variant="outline" className="h-20 flex-col">
                      <div className="w-8 h-8 bg-blue-500 rounded-full mb-2"></div>
                      <span className="text-xs">نقطة تنقل</span>
                    </Button>
                    <Button variant="outline" className="h-20 flex-col">
                      <div className="w-8 h-8 bg-orange-500 rounded-full mb-2"></div>
                      <span className="text-xs">نقطة معلومات</span>
                    </Button>
                    <Button variant="outline" className="h-20 flex-col">
                      <div className="w-8 h-8 bg-green-500 rounded-full mb-2"></div>
                      <span className="text-xs">نقطة وسائط</span>
                    </Button>
                    <Button variant="outline" className="h-20 flex-col">
                      <div className="w-8 h-8 bg-purple-500 rounded-full mb-2"></div>
                      <span className="text-xs">نقطة مخصصة</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Scene List */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">المشاهد المتاحة</h3>
              {scenes.map((scene, index) => (
                <Card 
                  key={index}
                  className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                    selectedScene === index ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => setSelectedScene(index)}
                >
                  <CardContent className="p-4">
                    <div className="flex space-x-4">
                      <img 
                        src={scene.image}
                        alt={scene.title}
                        className="w-20 h-16 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h4 className="font-medium text-sm mb-1">{scene.title}</h4>
                        <p className="text-xs text-muted-foreground line-clamp-2">
                          {scene.description}
                        </p>
                        <div className="flex items-center space-x-2 mt-2 text-xs text-muted-foreground">
                          <span>{scene.hotspots.length} نقاط تفاعل</span>
                          <span>•</span>
                          <span>{scene.stats.views} مشاهدة</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              <Button variant="outline" className="w-full">
                إضافة مشهد جديد
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Scenes;