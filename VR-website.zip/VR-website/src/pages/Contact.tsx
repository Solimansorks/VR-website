import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mail, Phone, MapPin, Clock, MessageCircle, Headphones, FileText } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Contact = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Page Header */}
      <section className="bg-gradient-to-r from-primary to-accent text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold font-poppins mb-4">
            تواصل معنا
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            نحن هنا لمساعدتك في كل ما تحتاجه. لا تتردد في التواصل معنا
          </p>
        </div>
      </section>

      {/* Contact Content */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <h2 className="text-2xl font-bold">أرسل رسالة</h2>
                  <p className="text-muted-foreground">
                    سنقوم بالرد عليك في أقرب وقت ممكن
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">الاسم الكامل *</label>
                      <Input placeholder="أدخل اسمك الكامل" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">البريد الإلكتروني *</label>
                      <Input type="email" placeholder="your@email.com" />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">رقم الهاتف</label>
                      <Input placeholder="+201555210800" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">نوع الاستفسار</label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر نوع الاستفسار" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="support">دعم فني</SelectItem>
                          <SelectItem value="sales">استفسار مبيعات</SelectItem>
                          <SelectItem value="feature">طلب ميزة جديدة</SelectItem>
                          <SelectItem value="partnership">شراكة</SelectItem>
                          <SelectItem value="other">أخرى</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">الموضوع *</label>
                    <Input placeholder="موضوع رسالتك" />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">الرسالة *</label>
                    <Textarea 
                      placeholder="اكتب رسالتك هنا..." 
                      className="min-h-32"
                    />
                  </div>
                  
                  <Button className="w-full button-gradient" size="lg">
                    إرسال الرسالة
                  </Button>
                </CardContent>
              </Card>
            </div>
            
            {/* Contact Info */}
            <div className="space-y-6">
              {/* Quick Contact */}
              <Card>
                <CardHeader>
                  <h3 className="text-lg font-semibold">معلومات التواصل</h3>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Mail className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">البريد الإلكتروني</h4>
                      <p className="text-sm text-muted-foreground">info@we3ds.com</p>
                      <p className="text-sm text-muted-foreground">support@we3ds.com</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Phone className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">الهاتف</h4>
                      <p className="text-sm text-muted-foreground">+201555210800</p>
                      <p className="text-sm text-muted-foreground">+201555210800</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <MapPin className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">العنوان</h4>
                      <p className="text-sm text-muted-foreground">
                           <br />
                        جمهوريه مصر العربيه .طنطا  
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Clock className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">ساعات العمل</h4>
                      <p className="text-sm text-muted-foreground">
                        17:00<br />
                        الجمعة - السبت: مغلق
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Support Channels */}
              <Card>
                <CardHeader>
                  <h3 className="text-lg font-semibold">قنوات الدعم</h3>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button variant="outline" className="w-full justify-start h-auto p-4">
                    <MessageCircle className="w-5 h-5 mr-3" />
                    <div className="text-left">
                      <p className="font-medium">الدردشة المباشرة</p>
                      <p className="text-sm text-muted-foreground">متاح 24/7</p>
                    </div>
                  </Button>
                  
                  <Button variant="outline" className="w-full justify-start h-auto p-4">
                    <Headphones className="w-5 h-5 mr-3" />
                    <div className="text-left">
                      <p className="font-medium">الدعم الصوتي</p>
                      <p className="text-sm text-muted-foreground">9:00 - 18:00</p>
                    </div>
                  </Button>
                  
                  <Button variant="outline" className="w-full justify-start h-auto p-4">
                    <FileText className="w-5 h-5 mr-3" />
                    <div className="text-left">
                      <p className="font-medium">مركز المساعدة</p>
                      <p className="text-sm text-muted-foreground">أدلة ومقالات</p>
                    </div>
                  </Button>
                </CardContent>
              </Card>
              
              {/* FAQ */}
              <Card>
                <CardHeader>
                  <h3 className="text-lg font-semibold">أسئلة شائعة</h3>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium text-sm mb-1">كيف أبدأ في إنشاء جولة افتراضية؟</h4>
                    <p className="text-xs text-muted-foreground">
                      قم بالتسجيل مجاناً واتبع المعالج البسيط لرفع صورك البانورامية.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm mb-1">ما هي أنواع الملفات المدعومة؟</h4>
                    <p className="text-xs text-muted-foreground">
                      ندعم JPEG وPNG للصور، وMP4 للفيديوهات البانورامية.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm mb-1">هل يمكنني تجربة المنصة مجاناً؟</h4>
                    <p className="text-xs text-muted-foreground">
                      نعم، نوفر حساب مجاني يتيح لك إنشاء 3 جولات شهرياً.
                    </p>
                  </div>
                  
                  <Button variant="link" className="h-auto p-0 text-primary">
                    عرض جميع الأسئلة الشائعة
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Contact;