import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, Grid, List } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import TourCard from "@/components/TourCard";
import panoramaHotel from "@/assets/panorama-hotel-lobby.jpg";
import panoramaApartment from "@/assets/panorama-apartment.jpg";
import panoramaGallery from "@/assets/panorama-gallery.jpg";

const Tours = () => {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const categories = [
    { value: "all", label: "جميع الفئات", labelEn: "All Categories" },
    { value: "real-estate", label: "عقارات", labelEn: "Real Estate" },
    { value: "hotels", label: "فنادق", labelEn: "Hotels" },
    { value: "museums", label: "متاحف", labelEn: "Museums" },
    { value: "restaurants", label: "مطاعم", labelEn: "Restaurants" },
    { value: "retail", label: "متاجر", labelEn: "Retail" },
  ];

  const tours = [
    {
      title: "فندق ريتز كارلتون الرياض",
      titleEn: "Ritz Carlton Riyadh Hotel",
      description: "جولة افتراضية فاخرة في أحد أفخم فنادق الرياض مع أجنحة مذهلة ومرافق عالمية المستوى",
      image: panoramaHotel,
      category: "فنادق",
      categoryEn: "Hotels",
      views: 15420,
      duration: "8 دقائق",
      location: "الرياض، السعودية",
      isPremium: true,
    },
    {
      title: "شقة سكنية فاخرة في دبي",
      titleEn: "Luxury Apartment in Dubai",
      description: "شقة عصرية بإطلالة رائعة على برج خليفة مع تصميم داخلي أنيق وأثاث فاخر",
      image: panoramaApartment,
      category: "عقارات",
      categoryEn: "Real Estate", 
      views: 8930,
      duration: "6 دقائق",
      location: "دبي، الإمارات",
      isPremium: false,
    },
    {
      title: "معرض الفن المعاصر",
      titleEn: "Contemporary Art Gallery",
      description: "جولة ثقافية في معرض فني يضم أعمال فنية معاصرة من فنانين عالميين ومحليين",
      image: panoramaGallery,
      category: "متاحف",
      categoryEn: "Museums",
      views: 5670,
      duration: "12 دقيقة",
      location: "جدة، السعودية",
      isPremium: false,
    },
    {
      title: "قصر تراثي تاريخي",
      titleEn: "Historic Heritage Palace",
      description: "استكشف التراث العربي الأصيل في قصر تاريخي مع العمارة التقليدية والزخارف الإسلامية",
      image: panoramaHotel,
      category: "متاحف",
      categoryEn: "Museums",
      views: 12350,
      duration: "15 دقيقة",
      location: "الدرعية، السعودية",
      isPremium: true,
    },
    {
      title: "مجمع تجاري حديث",
      titleEn: "Modern Shopping Complex",
      description: "تجربة تسوق افتراضية في أحد أكبر المجمعات التجارية مع متاجر عالمية ومطاعم متنوعة",
      image: panoramaApartment,
      category: "متاجر",
      categoryEn: "Retail",
      views: 6890,
      duration: "10 دقائق",
      location: "الكويت، الكويت",
      isPremium: false,
    },
    {
      title: "مطعم فاخر على البحر",
      titleEn: "Luxury Seafront Restaurant",
      description: "تجربة طعام افتراضية في مطعم فاخر بإطلالة ساحرة على البحر الأحمر",
      image: panoramaGallery,
      category: "مطاعم",
      categoryEn: "Restaurants",
      views: 4520,
      duration: "7 دقائق",
      location: "جدة، السعودية",
      isPremium: false,
    },
  ];

  const filteredTours = selectedCategory === "all" 
    ? tours 
    : tours.filter(tour => tour.categoryEn.toLowerCase() === selectedCategory);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Page Header */}
      <section className="bg-gradient-to-r from-primary to-accent text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold font-poppins mb-4">
            اكتشف الجولات الافتراضية
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            استكشف العالم من خلال جولات افتراضية مذهلة بتقنية 360 درجة
          </p>
        </div>
      </section>

      {/* Filters and Search */}
      <section className="py-8 border-b bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4 flex-1">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="ابحث عن الجولات..."
                  className="pl-10"
                />
              </div>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="اختر الفئة" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant={viewMode === "grid" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("grid")}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("list")}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* Quick filters */}
          <div className="flex flex-wrap gap-2 mt-4">
            <Badge variant="secondary" className="cursor-pointer">الأكثر شعبية</Badge>
            <Badge variant="outline" className="cursor-pointer">الأحدث</Badge>
            <Badge variant="outline" className="cursor-pointer">مميز</Badge>
            <Badge variant="outline" className="cursor-pointer">مجاني</Badge>
          </div>
        </div>
      </section>

      {/* Tours Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold">
              {filteredTours.length} جولة متاحة
            </h2>
            <Select defaultValue="popular">
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">الأكثر شعبية</SelectItem>
                <SelectItem value="newest">الأحدث</SelectItem>
                <SelectItem value="rating">الأعلى تقييماً</SelectItem>
                <SelectItem value="views">الأكثر مشاهدة</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className={`grid gap-6 ${
            viewMode === "grid" 
              ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" 
              : "grid-cols-1"
          }`}>
            {filteredTours.map((tour, index) => (
              <TourCard key={index} {...tour} />
            ))}
          </div>
          
          {/* Load More */}
          <div className="text-center mt-12">
            <Button variant="outline" size="lg">
              تحميل المزيد من الجولات
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Tours;